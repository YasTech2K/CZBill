@echo off
cd /d "%~dp0portal"
echo Starting Coffee Zone Sales Portal...
python app.py
pause
