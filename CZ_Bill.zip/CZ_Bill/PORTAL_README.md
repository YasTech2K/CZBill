# Coffee Zone Sales Portal

Web portal for daily sales entry, Excel sync, analytics dashboard, download, and email sharing.

## Quick start

1. Install dependencies (once):

   ```powershell
   pip install -r requirements.txt
   ```

2. Copy `.env.example` to `.env` and set your Excel file path if needed.

3. Start the portal:

   - Double-click `start_portal.bat`, or
   - `cd portal` then `python app.py`

4. Open in browser: **http://127.0.0.1:5050**

## Features

| Page | What it does |
|------|----------------|
| **Daily Entry** | **Paste raw report** (WhatsApp text) → Parse & save to Excel, or use the manual form |
| **Dashboard** | KPIs, charts, full data table, download Excel/CSV, email report |

- **Paste raw report** — copy the full daily WhatsApp message, paste in the box, click **Parse & save to Excel** (same parser as the original chat import). Use **Preview** first to check dates and totals.
- **Load existing** — fill the form for a date already in Excel (to edit).
- **Use yesterday's closing cash** — pre-fills opening cash from the last saved day.
- Each save creates a timestamped backup in the **`backups`** folder: `Coffee_Zone_Daily_Sales_Report_YYYYMMDD_HHMMSS.xlsx`

## Email sharing

**Option A — Web setup (recommended)**

1. Open **http://127.0.0.1:5050/settings/email**
2. Choose Gmail or Outlook, enter your email and **app password**
3. Click **Save email settings** → **Send test email**
4. From **Dashboard** → **Share by Email** to send the Excel report

**Option B — Command line**

```powershell
cd C:\Users\S494819\Documents\CZ_Bill
python setup_email.py
```

**Gmail:** Create an [App Password](https://myaccount.google.com/apppasswords) (requires 2-Step Verification).  
**Outlook:** Use `smtp.office365.com`, port `587`, work email + password or app password.

Settings are stored in `.env` in the CZ_Bill folder.

## Security (optional)

Set `PORTAL_PIN=1234` in `.env` to require a PIN before using the portal.

## Network access

To open from phone/tablet on same Wi‑Fi, set in `.env`:

```
HOST=0.0.0.0
PORT=5050
```

Then browse to `http://<your-PC-IP>:5050`. Use a PIN in production.

## Excel file

Keep `Coffee_Zone_Daily_Sales_Report.xlsx` as your master file. The portal reads and writes the monthly sheets (January 2026, February 2026, etc.) — same structure as the imported report.
