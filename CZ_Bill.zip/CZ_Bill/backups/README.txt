Excel backups are saved here automatically when you save from the portal.
Each file is named: Coffee_Zone_Daily_Sales_Report_YYYYMMDD_HHMMSS.xlsx

You can delete old backups anytime to free disk space.
