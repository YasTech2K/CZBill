"""Portal configuration — copy .env.example to .env and edit."""
import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
ENV_FILE = ROOT / ".env"


def reload_env() -> None:
    """Reload .env (after saving settings from the portal)."""
    load_dotenv(ENV_FILE, override=True)
    _apply()


def _apply() -> None:
    global EXCEL_FILE, SECRET_KEY, PORTAL_PIN, HOST, PORT
    global SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, SMTP_FROM
    global SMTP_USE_TLS, SMTP_USE_SSL, SMTP_PROVIDER, DEFAULT_REPORT_EMAIL
    global BACKUP_DIR
    global ADMIN_USERNAME, ADMIN_PASSWORD, STAFF_USERNAME, STAFF_PASSWORD

    EXCEL_FILE = os.getenv(
        "EXCEL_FILE",
        str(ROOT / "Coffee_Zone_Daily_Sales_Report.xlsx"),
    )
    SECRET_KEY = os.getenv("SECRET_KEY", "change-me-in-production-cz-portal")
    PORTAL_PIN = os.getenv("PORTAL_PIN", "")
    HOST = os.getenv("HOST", "127.0.0.1")
    PORT = int(os.getenv("PORT", "5050"))

    ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
    ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")
    STAFF_USERNAME = os.getenv("STAFF_USERNAME", "staff")
    STAFF_PASSWORD = os.getenv("STAFF_PASSWORD", "staff123")

    SMTP_PROVIDER = os.getenv("SMTP_PROVIDER", "gmail")
    SMTP_HOST = os.getenv("SMTP_HOST", "")
    SMTP_PORT = int(os.getenv("SMTP_PORT", "587") or "587")
    SMTP_USER = os.getenv("SMTP_USER", "")
    SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
    SMTP_FROM = os.getenv("SMTP_FROM", "") or SMTP_USER
    SMTP_USE_TLS = os.getenv("SMTP_USE_TLS", "true").lower() in ("1", "true", "yes")
    SMTP_USE_SSL = os.getenv("SMTP_USE_SSL", "false").lower() in ("1", "true", "yes")
    DEFAULT_REPORT_EMAIL = os.getenv("DEFAULT_REPORT_EMAIL", "")
    BACKUP_DIR = os.getenv("BACKUP_DIR", str(ROOT / "backups"))


# Initial load
load_dotenv(ENV_FILE)
_apply()
