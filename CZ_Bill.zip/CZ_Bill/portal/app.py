"""Coffee Zone Sales Portal — web entry, dashboard, Excel sync."""
from __future__ import annotations

import csv
import io
from collections import defaultdict
from datetime import date, datetime
from functools import wraps
from pathlib import Path

from flask import (
    Flask,
    jsonify,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)

import config
from excel_store import (
    backup_workbook,
    excel_path,
    get_latest_record,
    get_record,
    load_all_records,
    upsert_record,
    upsert_records_batch,
)
from raw_parser import parse_raw_text
from sales_schema import COLUMNS, FIELD_KEYS
from env_manager import read_env, write_env_values
from email_service import (
    PROVIDERS,
    apply_provider_preset,
    is_configured,
    send_email,
    send_test_email,
    status as email_status,
)

app = Flask(__name__)
app.secret_key = config.SECRET_KEY


STATIC_VERSION = "5"  # bump when JS/CSS change (avoids stale browser cache)


@app.context_processor
def inject_config():
    return {
        "config": config, 
        "static_v": STATIC_VERSION,
        "user": session.get("user"),
        "is_admin": session.get("role") == "admin"
    }


@app.after_request
def disable_static_cache(response):
    if request.path.startswith("/static/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate"
    return response


def login_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if not session.get("user"):
            if request.path.startswith("/api/"):
                return jsonify({"error": "Login required"}), 401
            return redirect(url_for("login", next=request.url))
        return f(*args, **kwargs)

    return wrapped


def admin_required(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        if not session.get("user"):
            if request.path.startswith("/api/"):
                return jsonify({"error": "Login required"}), 401
            return redirect(url_for("login", next=request.url))
        if session.get("role") != "admin":
            if request.path.startswith("/api/"):
                return jsonify({"error": "Admin access required"}), 403
            return redirect(url_for("index"))
        return f(*args, **kwargs)

    return wrapped


@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "").strip()
        
        if username == config.ADMIN_USERNAME and password == config.ADMIN_PASSWORD:
            session["user"] = username
            session["role"] = "admin"
            return redirect(request.args.get("next") or url_for("index"))
        elif username == config.STAFF_USERNAME and password == config.STAFF_PASSWORD:
            session["user"] = username
            session["role"] = "staff"
            return redirect(request.args.get("next") or url_for("index"))
        else:
            error = "Invalid username or password"
    return render_template("login.html", error=error)


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/")
@login_required
def index():
    return render_template("entry.html")


@app.route("/dashboard")
@admin_required
def dashboard():
    return render_template("dashboard.html")


@app.route("/settings/email")
@admin_required
def email_settings_page():
    return render_template("email_settings.html", providers=PROVIDERS)


@app.route("/api/health")
def health():
    path = excel_path()
    return jsonify(
        {
            "ok": True,
            "excel_exists": path.exists(),
            "excel_path": str(path),
        }
    )


@app.route("/api/records/latest")
@login_required
def api_latest():
    rec = get_latest_record()
    return jsonify({"record": rec})


@app.route("/api/records/<date_str>")
@login_required
def api_get_one(date_str: str):
    try:
        dt = datetime.strptime(date_str, "%Y-%m-%d").date()
    except ValueError:
        return jsonify({"error": "Invalid date"}), 400
    rec = get_record(dt)
    return jsonify({"record": rec})


@app.route("/api/records", methods=["GET"])
@admin_required
def api_list():
    records = load_all_records()
    month = request.args.get("month")
    if month:
        records = [r for r in records if r["date"].startswith(month)]
    return jsonify({"records": records, "count": len(records)})


@app.route("/api/records", methods=["POST"])
@login_required
def api_upsert():
    data = request.get_json(force=True, silent=True) or {}
    if not data.get("date"):
        return jsonify({"error": "date is required"}), 400
    try:
        saved = upsert_record(data)
        return jsonify(
            {
                "ok": True,
                "message": "Saved to Excel successfully",
                "record": saved,
            }
        )
    except FileNotFoundError as e:
        return jsonify({"error": str(e)}), 404
    except PermissionError:
        return jsonify(
            {
                "error": "Cannot write to Excel — close the file in Excel and try again.",
            }
        ), 423
    except Exception as e:
        return jsonify({"error": f"Failed to save: {e}"}), 500


@app.route("/api/records/from-raw", methods=["POST"])
@login_required
def api_from_raw():
    body = request.get_json(force=True, silent=True) or {}
    raw_text = (body.get("raw_text") or "").strip()
    preview_only = bool(body.get("preview"))

    if not raw_text:
        return jsonify({"error": "Paste your daily report text first"}), 400

    records = parse_raw_text(raw_text)
    if not records:
        return jsonify(
            {
                "error": "Could not parse a date from the pasted text. "
                "Include a line like Date: 06/05/2026 or 17/01/2026",
            }
        ), 400

    if preview_only:
        return jsonify(
            {
                "ok": True,
                "preview": True,
                "count": len(records),
                "dates": [r["date"] for r in records],
                "records": records,
            }
        )

    try:
        saved = upsert_records_batch(records)
        dates = ", ".join(r["date"] for r in saved)
        msg = (
            f"Updated Excel for {len(saved)} day(s): {dates}"
            if len(saved) > 1
            else f"Updated Excel for {dates}"
        )
        return jsonify(
            {
                "ok": True,
                "message": msg,
                "count": len(saved),
                "records": saved,
            }
        )
    except FileNotFoundError as e:
        return jsonify({"error": str(e)}), 404
    except PermissionError:
        return jsonify(
            {
                "error": "Cannot write to Excel — close the file in Excel and try again.",
            }
        ), 423
    except Exception as e:
        app.logger.exception("from-raw save failed")
        return jsonify({"error": f"Failed to save: {e}"}), 500


@app.route("/api/analytics/summary")
@admin_required
def api_summary():
    records = load_all_records()
    if not records:
        return jsonify({"summary": {}, "by_month": []})

    total_sales = sum(r.get("total_sales") or 0 for r in records)
    total_cash = sum(r.get("cash_sale") or 0 for r in records)
    total_card = sum(r.get("card_total") or 0 for r in records)
    total_expense = sum(r.get("cash_expense") or 0 for r in records)

    by_month: dict[str, dict] = defaultdict(
        lambda: {
            "days": 0,
            "total_sales": 0,
            "cash_sale": 0,
            "card_total": 0,
            "cash_expense": 0,
        }
    )
    for r in records:
        mk = r["date"][:7]
        by_month[mk]["days"] += 1
        by_month[mk]["total_sales"] += r.get("total_sales") or 0
        by_month[mk]["cash_sale"] += r.get("cash_sale") or 0
        by_month[mk]["card_total"] += r.get("card_total") or 0
        by_month[mk]["cash_expense"] += r.get("cash_expense") or 0

    month_list = []
    for mk in sorted(by_month.keys()):
        m = by_month[mk]
        days = m["days"] or 1
        month_list.append(
            {
                "month": mk,
                "label": datetime.strptime(mk + "-01", "%Y-%m-%d").strftime("%b %Y"),
                "days": m["days"],
                "total_sales": round(m["total_sales"], 2),
                "cash_sale": round(m["cash_sale"], 2),
                "card_total": round(m["card_total"], 2),
                "cash_expense": round(m["cash_expense"], 2),
                "avg_daily_sales": round(m["total_sales"] / days, 2),
            }
        )

    days_count = len(records)
    return jsonify(
        {
            "summary": {
                "days_recorded": days_count,
                "date_from": records[0]["date"],
                "date_to": records[-1]["date"],
                "total_sales": round(total_sales, 2),
                "total_cash_sales": round(total_cash, 2),
                "total_card_sales": round(total_card, 2),
                "total_cash_expense": round(total_expense, 2),
                "avg_daily_sales": round(total_sales / days_count, 2) if days_count else 0,
            },
            "by_month": month_list,
        }
    )


@app.route("/api/analytics/trends")
@admin_required
def api_trends():
    records = load_all_records()
    return jsonify(
        {
            "labels": [r["date"] for r in records],
            "total_sales": [r.get("total_sales") or 0 for r in records],
            "cash_sale": [r.get("cash_sale") or 0 for r in records],
            "card_total": [r.get("card_total") or 0 for r in records],
        }
    )


@app.route("/api/export/excel")
@admin_required
def export_excel():
    path = excel_path()
    if not path.exists():
        return jsonify({"error": "Excel file not found"}), 404
    return send_file(
        path,
        as_attachment=True,
        download_name=path.name,
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    )


@app.route("/api/export/csv")
@admin_required
def export_csv():
    records = load_all_records()
    output = io.StringIO()
    headers = [label for label, _ in COLUMNS]
    keys = [k for _, k in COLUMNS]
    writer = csv.writer(output)
    writer.writerow(headers)
    for r in records:
        writer.writerow([r.get(k, "") for k in keys])
    buf = io.BytesIO(output.getvalue().encode("utf-8-sig"))
    buf.seek(0)
    name = f"Coffee_Zone_Sales_{date.today().isoformat()}.csv"
    return send_file(buf, as_attachment=True, download_name=name, mimetype="text/csv")


@app.route("/api/backup", methods=["POST"])
@admin_required
def api_backup():
    path = excel_path()
    if not path.exists():
        return jsonify({"error": "Excel file not found"}), 404
    dest = backup_workbook(path)
    return jsonify({"ok": True, "backup": str(dest)})


@app.route("/api/email/status")
@admin_required
def api_email_status():
    return jsonify({"status": email_status(), "providers": {k: v["label"] for k, v in PROVIDERS.items()}})


@app.route("/api/email/config", methods=["GET"])
@admin_required
def api_email_config_get():
    env = read_env()
    return jsonify(
        {
            "provider": env.get("SMTP_PROVIDER", config.SMTP_PROVIDER),
            "host": env.get("SMTP_HOST", config.SMTP_HOST),
            "port": env.get("SMTP_PORT", str(config.SMTP_PORT)),
            "user": env.get("SMTP_USER", config.SMTP_USER),
            "from": env.get("SMTP_FROM", config.SMTP_FROM),
            "default_to": env.get("DEFAULT_REPORT_EMAIL", config.DEFAULT_REPORT_EMAIL),
            "use_tls": env.get("SMTP_USE_TLS", str(config.SMTP_USE_TLS)).lower() in ("true", "1", "yes"),
            "use_ssl": env.get("SMTP_USE_SSL", str(config.SMTP_USE_SSL)).lower() in ("true", "1", "yes"),
            "has_password": bool(env.get("SMTP_PASSWORD") or config.SMTP_PASSWORD),
        }
    )


@app.route("/api/email/config", methods=["POST"])
@admin_required
def api_email_config_save():
    body = request.get_json(force=True, silent=True) or {}
    provider = (body.get("provider") or "gmail").strip()
    updates = apply_provider_preset(provider)

    if provider == "custom" or body.get("host"):
        updates["SMTP_HOST"] = (body.get("host") or updates["SMTP_HOST"]).strip()
        updates["SMTP_PORT"] = str(body.get("port") or updates["SMTP_PORT"])
        if "use_tls" in body:
            updates["SMTP_USE_TLS"] = "true" if body.get("use_tls") else "false"
        if "use_ssl" in body:
            updates["SMTP_USE_SSL"] = "true" if body.get("use_ssl") else "false"

    user = (body.get("user") or "").strip()
    if user:
        updates["SMTP_USER"] = user
        if not body.get("from"):
            updates["SMTP_FROM"] = user

    from_addr = (body.get("from") or "").strip()
    if from_addr:
        updates["SMTP_FROM"] = from_addr

    password = body.get("password")
    if password:
        updates["SMTP_PASSWORD"] = password

    default_to = (body.get("default_to") or "").strip()
    updates["DEFAULT_REPORT_EMAIL"] = default_to

    write_env_values(updates)
    config.reload_env()

    return jsonify(
        {
            "ok": True,
            "message": "Email settings saved. Restart not required.",
            "status": email_status(),
        }
    )


@app.route("/api/email/test", methods=["POST"])
@admin_required
def api_email_test():
    body = request.get_json(force=True, silent=True) or {}
    to_addr = (body.get("to") or config.DEFAULT_REPORT_EMAIL or config.SMTP_USER).strip()
    if not to_addr:
        return jsonify({"error": "Enter a test recipient email address"}), 400
    if not is_configured():
        return jsonify({"error": "Save SMTP settings first (email + app password)"}), 400
    try:
        send_test_email(to_addr)
        return jsonify({"ok": True, "message": f"Test email sent to {to_addr}"})
    except Exception as e:
        return jsonify({"error": f"Test failed: {e}"}), 500


@app.route("/api/share/email", methods=["POST"])
@admin_required
def share_email():
    if not is_configured():
        return jsonify(
            {
                "error": "Email not configured. Open Email Setup and save your mail settings.",
                "setup_url": url_for("email_settings_page"),
            }
        ), 400

    body = request.get_json(force=True, silent=True) or {}
    to_addr = (body.get("to") or config.DEFAULT_REPORT_EMAIL or "").strip()
    subject = body.get("subject", "Coffee Zone Sales Report")
    message = body.get("message", "Please find the attached sales report.")
    fmt = body.get("format", "excel")

    if not to_addr:
        return jsonify({"error": "Recipient email (to) is required"}), 400

    path = excel_path()
    if fmt == "csv":
        records = load_all_records()
        output = io.StringIO()
        keys = [k for _, k in COLUMNS]
        writer = csv.writer(output)
        writer.writerow([label for label, _ in COLUMNS])
        for r in records:
            writer.writerow([r.get(k, "") for k in keys])
        attachment_data = output.getvalue().encode("utf-8-sig")
        filename = f"Coffee_Zone_Sales_{date.today().isoformat()}.csv"
        maintype, subtype = "text", "csv"
    else:
        if not path.exists():
            return jsonify({"error": "Excel file not found"}), 404
        attachment_data = path.read_bytes()
        filename = path.name
        maintype = "application"
        subtype = "vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    try:
        send_email(
            [to_addr],
            subject,
            message,
            attachment=attachment_data,
            filename=filename,
            maintype=maintype,
            subtype=subtype,
        )
    except Exception as e:
        return jsonify({"error": f"Email failed: {e}"}), 500

    return jsonify({"ok": True, "message": f"Report sent to {to_addr}"})


if __name__ == "__main__":
    print(f"Coffee Zone Portal: http://{config.HOST}:{config.PORT}")
    print(f"Excel file: {excel_path()}")
    if is_configured():
        print(f"Email: configured ({config.SMTP_FROM} via {config.SMTP_HOST})")
    else:
        print("Email: not configured — open http://127.0.0.1:{}/settings/email".format(config.PORT))
    app.run(host=config.HOST, port=config.PORT, debug=True)
