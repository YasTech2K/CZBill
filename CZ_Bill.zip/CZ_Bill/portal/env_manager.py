"""Read and update .env file for portal settings."""
from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def env_path() -> Path:
    return ROOT / ".env"


def read_env() -> dict[str, str]:
    path = env_path()
    if not path.exists():
        return {}
    out: dict[str, str] = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        out[key.strip()] = val.strip().strip('"').strip("'")
    return out


def write_env_values(updates: dict[str, str]) -> None:
    """Merge keys into .env (create file if missing)."""
    path = env_path()
    lines: list[str] = []
    if path.exists():
        lines = path.read_text(encoding="utf-8").splitlines()

    done: set[str] = set()
    new_lines: list[str] = []
    key_re = re.compile(r"^([A-Za-z_][A-Za-z0-9_]*)\s*=")

    for line in lines:
        m = key_re.match(line.strip())
        if m and m.group(1) in updates:
            key = m.group(1)
            new_lines.append(f"{key}={_escape(updates[key])}")
            done.add(key)
        else:
            new_lines.append(line)

    for key, val in updates.items():
        if key not in done:
            new_lines.append(f"{key}={_escape(val)}")

    path.write_text("\n".join(new_lines).rstrip() + "\n", encoding="utf-8")


def _escape(val: str) -> str:
    if not val:
        return ""
    if any(c in val for c in " #=\t\n\r"):
        return '"' + val.replace('"', '\\"') + '"'
    return val
