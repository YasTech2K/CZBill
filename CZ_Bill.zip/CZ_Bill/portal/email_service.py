"""Send sales reports via SMTP (Gmail, Outlook, custom)."""
from __future__ import annotations

import smtplib
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Any

import config

# Preset SMTP settings — user still supplies email + app password in .env
PROVIDERS: dict[str, dict[str, Any]] = {
    "gmail": {
        "label": "Gmail",
        "host": "smtp.gmail.com",
        "port": 587,
        "use_tls": True,
        "use_ssl": False,
        "help": "Use a Google App Password: https://myaccount.google.com/apppasswords",
    },
    "outlook": {
        "label": "Microsoft Outlook / Office 365",
        "host": "smtp.office365.com",
        "port": 587,
        "use_tls": True,
        "use_ssl": False,
        "help": "Use your Microsoft account password or app password if MFA is on.",
    },
    "outlook_live": {
        "label": "Outlook.com (personal)",
        "host": "smtp-mail.outlook.com",
        "port": 587,
        "use_tls": True,
        "use_ssl": False,
        "help": "Personal @outlook.com / @hotmail.com accounts.",
    },
    "yahoo": {
        "label": "Yahoo Mail",
        "host": "smtp.mail.yahoo.com",
        "port": 587,
        "use_tls": True,
        "use_ssl": False,
        "help": "Generate an app password in Yahoo account security settings.",
    },
    "custom": {
        "label": "Custom SMTP server",
        "host": "",
        "port": 587,
        "use_tls": True,
        "use_ssl": False,
        "help": "Enter host and port from your email provider.",
    },
}


def is_configured() -> bool:
    return bool(
        config.SMTP_HOST
        and config.SMTP_USER
        and config.SMTP_PASSWORD
        and config.SMTP_FROM
    )


def status() -> dict:
    user = config.SMTP_USER or ""
    masked = ""
    if user:
        parts = user.split("@")
        masked = (parts[0][:2] + "***@" + parts[1]) if len(parts) == 2 else "***"
    return {
        "configured": is_configured(),
        "provider": config.SMTP_PROVIDER,
        "host": config.SMTP_HOST,
        "port": config.SMTP_PORT,
        "from": config.SMTP_FROM,
        "user_masked": masked,
        "default_to": config.DEFAULT_REPORT_EMAIL,
        "use_tls": config.SMTP_USE_TLS,
        "use_ssl": config.SMTP_USE_SSL,
    }


def apply_provider_preset(provider: str) -> dict[str, str]:
    preset = PROVIDERS.get(provider, PROVIDERS["custom"])
    return {
        "SMTP_PROVIDER": provider,
        "SMTP_HOST": preset.get("host", ""),
        "SMTP_PORT": str(preset.get("port", 587)),
        "SMTP_USE_TLS": "true" if preset.get("use_tls") else "false",
        "SMTP_USE_SSL": "true" if preset.get("use_ssl") else "false",
    }


def send_email(
    to_addrs: list[str],
    subject: str,
    body: str,
    attachment: bytes | None = None,
    filename: str = "report.xlsx",
    maintype: str = "application",
    subtype: str = "vnd.openxmlformats-officedocument.spreadsheetml.sheet",
) -> None:
    if not is_configured():
        raise RuntimeError(
            "Email is not configured. Open Email Setup in the portal and save your SMTP settings."
        )

    msg = MIMEMultipart()
    msg["From"] = config.SMTP_FROM
    msg["To"] = ", ".join(to_addrs)
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain", "utf-8"))

    if attachment:
        part = MIMEBase(maintype, subtype)
        part.set_payload(attachment)
        encoders.encode_base64(part)
        part.add_header("Content-Disposition", f'attachment; filename="{filename}"')
        msg.attach(part)

    _smtp_send(msg, to_addrs)


def send_test_email(to_addr: str) -> None:
    send_email(
        [to_addr],
        "Coffee Zone Portal — test email",
        "Your email sharing is configured correctly.\n\n— Coffee Zone Sales Portal",
    )


def _smtp_send(msg: MIMEMultipart, recipients: list[str]) -> None:
    host = config.SMTP_HOST
    port = config.SMTP_PORT
    if config.SMTP_USE_SSL:
        with smtplib.SMTP_SSL(host, port, timeout=60) as server:
            server.login(config.SMTP_USER, config.SMTP_PASSWORD)
            server.sendmail(config.SMTP_FROM, recipients, msg.as_string())
    else:
        with smtplib.SMTP(host, port, timeout=60) as server:
            server.ehlo()
            if config.SMTP_USE_TLS:
                server.starttls()
                server.ehlo()
            server.login(config.SMTP_USER, config.SMTP_PASSWORD)
            server.sendmail(config.SMTP_FROM, recipients, msg.as_string())
