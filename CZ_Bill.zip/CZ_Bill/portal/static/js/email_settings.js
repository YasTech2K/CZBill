const $ = (id) => document.getElementById(id);
const PROVIDERS = window.EMAIL_PROVIDERS || {};

function showToast(msg, type = "success") {
  const t = $("toast");
  t.textContent = msg;
  t.className = `toast ${type}`;
  t.classList.remove("hidden");
  setTimeout(() => t.classList.add("hidden"), 6000);
}

async function api(path, opts = {}) {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json", ...opts.headers },
    credentials: "same-origin",
    ...opts,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
}

function updateProviderUI() {
  const key = $("provider").value;
  const p = PROVIDERS[key] || {};
  $("provider-help").textContent = p.help || "";
  $("custom-smtp").classList.toggle("hidden", key !== "custom");
  if (key !== "custom" && p.host) {
    $("host").value = p.host;
    $("port").value = p.port || 587;
    $("use_tls").checked = !!p.use_tls;
    $("use_ssl").checked = !!p.use_ssl;
  }
}

function setBanner(status) {
  const el = $("email-status-banner");
  if (status.configured) {
    el.className = "status-banner status-ok";
    el.textContent = `✓ Email ready — sending as ${status.from} via ${status.host}`;
  } else {
    el.className = "status-banner status-warn";
    el.textContent = "⚠ Email not configured — fill in the form below and click Save.";
  }
}

async function loadConfig() {
  const data = await api("/api/email/config");
  $("provider").value = data.provider || "gmail";
  $("host").value = data.host || "";
  $("port").value = data.port || 587;
  $("user").value = data.user || "";
  $("from").value = data.from || "";
  $("default_to").value = data.default_to || "";
  $("use_tls").checked = data.use_tls !== false;
  $("use_ssl").checked = !!data.use_ssl;
  if (data.has_password) {
    $("password").placeholder = "••••••••  (saved — enter only to change)";
  }
  updateProviderUI();
  const st = await api("/api/email/status");
  setBanner(st.status);
}

$("provider").addEventListener("change", updateProviderUI);

$("email-config-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const payload = {
    provider: $("provider").value,
    host: $("host").value,
    port: parseInt($("port").value, 10) || 587,
    user: $("user").value.trim(),
    from: $("from").value.trim() || $("user").value.trim(),
    password: $("password").value,
    default_to: $("default_to").value.trim(),
    use_tls: $("use_tls").checked,
    use_ssl: $("use_ssl").checked,
  };
  try {
    const data = await api("/api/email/config", {
      method: "POST",
      body: JSON.stringify(payload),
    });
    showToast(data.message);
    setBanner(data.status);
    $("password").value = "";
    $("password").placeholder = "••••••••  (saved — enter only to change)";
  } catch (err) {
    showToast(err.message, "error");
  }
});

$("btn-test").addEventListener("click", async () => {
  const to = $("default_to").value.trim() || $("user").value.trim();
  if (!to) {
    showToast("Enter your email or a default recipient first", "error");
    return;
  }
  try {
    const data = await api("/api/email/test", {
      method: "POST",
      body: JSON.stringify({ to }),
    });
    showToast(data.message);
  } catch (err) {
    showToast(err.message, "error");
  }
});

loadConfig().catch((e) => showToast(e.message, "error"));
