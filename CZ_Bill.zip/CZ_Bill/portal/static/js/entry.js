const $ = (id) => document.getElementById(id);

function num(id) {
  const v = parseFloat($(id).value);
  return Number.isFinite(v) ? v : 0;
}

function recalc() {
  const cashKept = num("cash_kept");
  const cashExp = num("cash_expense");
  const cashSale = cashKept + cashExp;
  const cardTotal = num("card_utap") + num("card_afs") + num("card_network");
  const totalSales = cashSale + cardTotal;
  $("out_cash_sale").textContent = cashSale.toFixed(2);
  $("out_card_total").textContent = cardTotal.toFixed(2);
  $("out_total_sales").textContent = totalSales.toFixed(2);
}

function showToast(msg, type = "success") {
  const t = $("toast");
  t.textContent = msg;
  t.className = `toast ${type}`;
  setTimeout(() => t.classList.add("hidden"), 5000);
}

function setFormFromRecord(rec) {
  if (!rec) return;
  const fields = [
    "cash_kept", "cash_expense", "card_utap", "card_afs", "card_network",
    "opening_cash", "total_cash_bal", "remaining_cash", "rifayi",
    "waste_oil", "float_cash", "petty_cash", "notes",
  ];
  fields.forEach((f) => {
    const el = $(f);
    if (!el) return;
    if (f === "notes") el.value = rec[f] || "";
    else if (rec[f] != null) el.value = rec[f];
  });
  recalc();
}

async function api(path, opts = {}) {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json", ...opts.headers },
    credentials: "same-origin",
    ...opts,
  });
  let data = {};
  const ct = res.headers.get("content-type") || "";
  if (ct.includes("application/json")) {
    data = await res.json().catch(() => ({}));
  } else if (!res.ok) {
    const text = await res.text();
    throw new Error(text.slice(0, 120) || res.statusText);
  }
  if (!res.ok) {
    if (res.status === 401) throw new Error("Session expired — refresh the page and log in again.");
    throw new Error(data.error || res.statusText || `Request failed (${res.status})`);
  }
  return data;
}

let datePicker = null;

function getSelectedDate() {
  if (datePicker?.selectedDates?.[0]) {
    const d = datePicker.selectedDates[0];
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  return $("date").value;
}

function initDatePicker() {
  const params = new URLSearchParams(window.location.search);
  const defaultDate = params.get("date") || new Date();

  datePicker = flatpickr("#date", {
    dateFormat: "d/m/Y",
    altInput: false,
    defaultDate,
    allowInput: false,
    clickOpens: true,
    disableMobile: false,
    animate: true,
    locale: { firstDayOfWeek: 1 },
    onChange() {
      $("date").dispatchEvent(new Event("change", { bubbles: true }));
    },
  });

  $("btn-open-calendar").addEventListener("click", (e) => {
    e.preventDefault();
    datePicker.open();
  });

  $("date").addEventListener("click", () => datePicker.open());

  if (params.get("date")) {
    setTimeout(() => $("btn-load-date").click(), 100);
  }
}

function initEntryPage() {
  initDatePicker();

document.querySelectorAll(".calc-trigger").forEach((el) => {
  el.addEventListener("input", recalc);
});

$("btn-load-date").addEventListener("click", async () => {
  const d = getSelectedDate();
  if (!d) return;
  try {
    const { record } = await api(`/api/records/${encodeURIComponent(d)}`);
    if (record) {
      setFormFromRecord(record);
      showToast("Loaded existing entry for this date");
    } else {
      showToast("No entry for this date — enter new data", "success");
    }
  } catch (e) {
    showToast(e.message, "error");
  }
});

$("btn-prefill-opening").addEventListener("click", async () => {
  try {
    const { record } = await api("/api/records/latest");
    if (record?.remaining_cash != null) {
      $("opening_cash").value = record.remaining_cash;
      showToast("Opening cash set from last day's remaining balance");
    } else {
      showToast("No previous record found", "error");
    }
  } catch (e) {
    showToast(e.message, "error");
  }
});

$("sales-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const btn = $("btn-submit");
  btn.disabled = true;
  btn.querySelector(".btn-text").classList.add("hidden");
  btn.querySelector(".btn-spinner").classList.remove("hidden");

  const cashKept = num("cash_kept");
  const cashExp = num("cash_expense");
  const payload = {
    date: getSelectedDate(),
    cash_kept: cashKept || null,
    cash_expense: cashExp || null,
    cash_sale: cashKept + cashExp,
    card_utap: num("card_utap") || null,
    card_afs: num("card_afs") || null,
    card_network: num("card_network") || null,
    card_total: num("card_utap") + num("card_afs") + num("card_network"),
    total_sales: cashKept + cashExp + num("card_utap") + num("card_afs") + num("card_network"),
    opening_cash: num("opening_cash") || null,
    total_cash_bal: num("total_cash_bal") || null,
    remaining_cash: num("remaining_cash") || null,
    rifayi: num("rifayi") || null,
    waste_oil: num("waste_oil") || null,
    float_cash: num("float_cash") || null,
    petty_cash: num("petty_cash") || null,
    notes: $("notes").value.trim(),
  };

  try {
    const data = await api("/api/records", {
      method: "POST",
      body: JSON.stringify(payload),
    });
    showToast(`✓ ${data.message} (sheet: ${data.record._sheet})`);
  } catch (err) {
    showToast(err.message, "error");
  } finally {
    btn.disabled = false;
    btn.querySelector(".btn-text").classList.remove("hidden");
    btn.querySelector(".btn-spinner").classList.add("hidden");
  }
});

recalc();

// --- Raw paste ---
document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((t) => t.classList.remove("active"));
    tab.classList.add("active");
    const isRaw = tab.dataset.tab === "raw";
    document.getElementById("panel-raw").classList.toggle("hidden", !isRaw);
    document.getElementById("panel-form").classList.toggle("hidden", isRaw);
  });
});

function renderRawPreview(records) {
  const box = $("raw-preview");
  if (!records.length) {
    box.classList.add("hidden");
    return;
  }
  const rows = records
    .map(
      (r) => `<tr>
        <td>${r.date}</td>
        <td>${(r.cash_sale ?? 0).toFixed(2)}</td>
        <td>${(r.card_total ?? 0).toFixed(2)}</td>
        <td><strong>${(r.total_sales ?? 0).toFixed(2)}</strong></td>
      </tr>`
    )
    .join("");
  box.innerHTML = `<h3>Will save ${records.length} day(s) to Excel</h3>
    <table><thead><tr><th>Date</th><th>Cash</th><th>Card</th><th>Total</th></tr></thead><tbody>${rows}</tbody></table>`;
  box.classList.remove("hidden");
}

async function submitRaw(preview) {
  const text = $("raw_text").value.trim();
  if (!text) {
    showToast("Paste your daily report text first", "error");
    return;
  }
  const btn = preview ? null : $("btn-raw-submit");
  if (btn) {
    btn.disabled = true;
    btn.querySelector(".btn-text").classList.add("hidden");
    btn.querySelector(".btn-spinner").classList.remove("hidden");
  }
  try {
    const data = await api("/api/records/from-raw", {
      method: "POST",
      body: JSON.stringify({ raw_text: text, preview }),
    });
    if (preview) {
      renderRawPreview(data.records);
      showToast(`Parsed ${data.count} day(s) — review below, then save`);
    } else {
      renderRawPreview(data.records);
      showToast(`✓ ${data.message}`);
      $("raw_text").value = "";
    }
  } catch (e) {
    showToast(e.message, "error");
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.querySelector(".btn-text").classList.remove("hidden");
      btn.querySelector(".btn-spinner").classList.add("hidden");
    }
  }
}

$("raw-form").addEventListener("submit", (e) => {
  e.preventDefault();
  submitRaw(false);
});
$("btn-raw-preview").addEventListener("click", () => submitRaw(true));
$("btn-raw-clear").addEventListener("click", () => {
  $("raw_text").value = "";
  $("raw-preview").classList.add("hidden");
});

} // initEntryPage

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initEntryPage);
} else {
  initEntryPage();
}
