const $ = (id) => document.getElementById(id);
let trendChart, monthlyChart, mixChart;

function fmt(n) {
  return Number(n).toLocaleString("en-AE", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function showToast(msg, type = "success") {
  const t = $("toast");
  t.textContent = msg;
  t.className = `toast ${type}`;
  setTimeout(() => t.classList.add("hidden"), 5000);
}

async function api(path, opts = {}) {
  const res = await fetch(path, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || res.statusText);
  return data;
}

const chartDefaults = {
  responsive: true,
  maintainAspectRatio: true,
  plugins: { legend: { labels: { color: "#a89f94" } } },
  scales: {
    x: { ticks: { color: "#a89f94", maxTicksLimit: 12 }, grid: { color: "#3d352c33" } },
    y: { ticks: { color: "#a89f94" }, grid: { color: "#3d352c33" } },
  },
};

function renderKpis(summary) {
  $("kpi-days").textContent = summary.days_recorded ?? "—";
  $("kpi-total").textContent = summary.total_sales != null ? fmt(summary.total_sales) : "—";
  $("kpi-avg").textContent = summary.avg_daily_sales != null ? fmt(summary.avg_daily_sales) : "—";
  const cash = summary.total_cash_sales || 0;
  const card = summary.total_card_sales || 0;
  const tot = cash + card || 1;
  $("kpi-split").textContent = `${((cash / tot) * 100).toFixed(0)}% cash / ${((card / tot) * 100).toFixed(0)}% card`;
}

function renderTable(records) {
  const tbody = $("records-body");
  tbody.innerHTML = records
    .slice()
    .reverse()
    .map(
      (r) => `
    <tr>
      <td>${r.date}</td>
      <td>${fmt(r.cash_sale || 0)}</td>
      <td>${fmt(r.card_total || 0)}</td>
      <td><strong>${fmt(r.total_sales || 0)}</strong></td>
      <td>${fmt(r.cash_expense || 0)}</td>
      <td>${fmt(r.remaining_cash || 0)}</td>
      <td><a class="link-edit" href="/?date=${r.date}#edit">Edit</a></td>
    </tr>`
    )
    .join("");
}

function renderCharts(summary, trends) {
  if (trendChart) trendChart.destroy();
  if (monthlyChart) monthlyChart.destroy();
  if (mixChart) mixChart.destroy();

  const ctx1 = $("chart-trend").getContext("2d");
  trendChart = new Chart(ctx1, {
    type: "line",
    data: {
      labels: trends.labels.map((d) => d.slice(5)),
      datasets: [
        {
          label: "Total sales",
          data: trends.total_sales,
          borderColor: "#c8956c",
          backgroundColor: "rgba(200,149,108,0.15)",
          fill: true,
          tension: 0.3,
        },
      ],
    },
    options: chartDefaults,
  });

  const months = summary.by_month || [];
  const ctx2 = $("chart-monthly").getContext("2d");
  monthlyChart = new Chart(ctx2, {
    type: "bar",
    data: {
      labels: months.map((m) => m.label),
      datasets: [
        {
          label: "Total sales (AED)",
          data: months.map((m) => m.total_sales),
          backgroundColor: "#8b5e3c",
        },
      ],
    },
    options: chartDefaults,
  });

  const ctx3 = $("chart-mix").getContext("2d");
  mixChart = new Chart(ctx3, {
    type: "doughnut",
    data: {
      labels: ["Cash sales", "Card sales"],
      datasets: [
        {
          data: [summary.summary.total_cash_sales, summary.summary.total_card_sales],
          backgroundColor: ["#c8956c", "#6bbf8a"],
        },
      ],
    },
    options: {
      responsive: true,
      plugins: { legend: { position: "bottom", labels: { color: "#a89f94" } } },
    },
  });
}

async function loadDashboard() {
  try {
    const [summaryData, trendsData, recordsData] = await Promise.all([
      api("/api/analytics/summary"),
      api("/api/analytics/trends"),
      api("/api/records"),
    ]);
    renderKpis(summaryData.summary);
    renderCharts(summaryData, trendsData);
    renderTable(recordsData.records);
  } catch (e) {
    showToast(e.message, "error");
  }
}

$("btn-refresh").addEventListener("click", loadDashboard);

async function loadEmailStatusForModal() {
  const el = document.getElementById("email-modal-status");
  const toInput = document.getElementById("email-to");
  if (!el) return;
  try {
    const { status } = await api("/api/email/status");
    if (status.configured) {
      el.textContent = `Ready: ${status.from} via ${status.host}`;
      el.className = "muted status-ok-text";
    } else {
      el.innerHTML = '⚠ Not configured — <a href="/settings/email">set up email</a> first.';
      el.className = "muted status-warn-text";
    }
    if (toInput && status.default_to) toInput.value = status.default_to;
  } catch {
    el.textContent = "Could not load email status.";
  }
}

$("btn-email-open").addEventListener("click", () => {
  $("email-modal").classList.remove("hidden");
  loadEmailStatusForModal();
});
$("btn-email-cancel").addEventListener("click", () => {
  $("email-modal").classList.add("hidden");
});
$("email-backdrop").addEventListener("click", () => {
  $("email-modal").classList.add("hidden");
});

$("email-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const fd = new FormData(e.target);
  try {
    const data = await api("/api/share/email", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        to: fd.get("to"),
        subject: fd.get("subject"),
        message: fd.get("message"),
        format: fd.get("format"),
      }),
    });
    showToast(data.message);
    $("email-modal").classList.add("hidden");
  } catch (err) {
    showToast(err.message, "error");
  }
});

loadDashboard();
