"""Parse pasted WhatsApp / daily report text into sales records."""
from __future__ import annotations

import re
import sys
from datetime import date, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from build_sales_report import completeness, parse_block, split_blocks  # noqa: E402


def _blocks_from_text(text: str) -> list[str]:
    text = text.strip()
    if not text:
        return []

    blocks = split_blocks(text)
    if blocks:
        return blocks

    # Single message without WhatsApp header / leading BISMILLAH
    if parse_block(text):
        return [text]

    prefixed = f"BISMILLAH\n\n{text}"
    blocks = split_blocks(prefixed)
    if blocks:
        return blocks

    if parse_block(prefixed):
        return [prefixed]

    # Split on BISMILLAH occurrences
    parts = re.split(r"(?i)(?=BISMILLAH)", text)
    out = []
    for p in parts:
        p = p.strip()
        if len(p) > 30 and parse_block(p):
            out.append(p)
    if out:
        return out

    return [text] if len(text) > 30 else []


def parse_raw_text(text: str) -> list[dict]:
    """Return parsed records (one per business date), best version kept on duplicates."""
    by_date: dict[str, dict] = {}
    scores: dict[str, int] = {}

    for block in _blocks_from_text(text):
        rec = parse_block(block)
        if not rec:
            continue
        dt = rec["date"]
        dt_date = dt.date() if isinstance(dt, datetime) else dt
        key = dt_date.isoformat()
        score = completeness(rec)
        if key not in by_date or score > scores.get(key, 0):
            by_date[key] = _parsed_to_payload(rec, dt_date)
            scores[key] = score

    records = sorted(by_date.values(), key=lambda r: r["date"])
    return records


def _parsed_to_payload(rec: dict, dt_date: date) -> dict:
    """Map parser output to portal / Excel field dict."""
    out: dict = {"date": dt_date.isoformat()}
    for key in (
        "cash_sale",
        "cash_kept",
        "cash_expense",
        "card_utap",
        "card_afs",
        "card_network",
        "card_total",
        "total_sales",
        "opening_cash",
        "total_cash_bal",
        "rifayi",
        "waste_oil",
        "float_cash",
        "petty_cash",
        "remaining_cash",
        "old_card_bal",
        "notes",
    ):
        val = rec.get(key)
        if val is not None and key != "notes":
            out[key] = float(val) if isinstance(val, (int, float)) else val
        elif key == "notes":
            out[key] = str(val or "")
        else:
            out[key] = None
    return out


def preview_raw_text(text: str) -> dict:
    records = parse_raw_text(text)
    return {
        "count": len(records),
        "dates": [r["date"] for r in records],
        "records": records,
    }
