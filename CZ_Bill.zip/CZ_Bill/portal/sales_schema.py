"""Shared column definitions for Excel and the web portal."""
from __future__ import annotations

from datetime import datetime

COLUMNS = [
    ("Date", "date"),
    ("Day", "day"),
    ("Cash Sale (AED)", "cash_sale"),
    ("Cash Kept (AED)", "cash_kept"),
    ("Cash Expense (AED)", "cash_expense"),
    ("Card U-Tap (AED)", "card_utap"),
    ("Card AFS (AED)", "card_afs"),
    ("Card Network (AED)", "card_network"),
    ("Total Card (AED)", "card_total"),
    ("Total Sales (AED)", "total_sales"),
    ("Opening Cash (AED)", "opening_cash"),
    ("Total Cash Bal. (AED)", "total_cash_bal"),
    ("Paid to Rifayi (AED)", "rifayi"),
    ("Waste Oil (AED)", "waste_oil"),
    ("Float (AED)", "float_cash"),
    ("Petty Cash (AED)", "petty_cash"),
    ("Remaining Cash (AED)", "remaining_cash"),
    ("Old Card Bal. (AED)", "old_card_bal"),
    ("Notes", "notes"),
]

FIELD_KEYS = [k for _, k in COLUMNS]
NUMERIC_KEYS = [k for k in FIELD_KEYS if k not in ("date", "day", "notes")]

HEADER_ROW = 4
DATA_START_ROW = 5
SKIP_SHEETS = {"Dashboard", "How to Use"}

MONEY_FMT = "#,##0.00"
DATE_FMT = "DD/MM/YYYY"


def month_sheet_name(dt: datetime) -> str:
    return dt.strftime("%B %Y")[:31]


def month_key(dt: datetime) -> str:
    return dt.strftime("%Y-%m")
