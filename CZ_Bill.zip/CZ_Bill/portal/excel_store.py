"""Read and write Coffee Zone sales data in the Excel workbook."""
from __future__ import annotations

import shutil
from datetime import date, datetime
from pathlib import Path
from typing import Any

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from sales_schema import (
    COLUMNS,
    DATA_START_ROW,
    DATE_FMT,
    FIELD_KEYS,
    HEADER_ROW,
    MONEY_FMT,
    SKIP_SHEETS,
    month_sheet_name,
)

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_EXCEL = ROOT / "Coffee_Zone_Daily_Sales_Report.xlsx"

THIN = Side(style="thin", color="B4C6E7")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
HEADER_FILL = PatternFill("solid", fgColor="1F4E79")
HEADER_FONT = Font(bold=True, color="FFFFFF", size=11)


def excel_path() -> Path:
    from config import EXCEL_FILE

    return Path(EXCEL_FILE)


def _parse_cell_date(value: Any) -> date | None:
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        for fmt in ("%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y"):
            try:
                return datetime.strptime(value.strip(), fmt).date()
            except ValueError:
                continue
    return None


def _coerce_float(value: Any) -> float | None:
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _row_to_record(ws, row: int) -> dict | None:
    dt = _parse_cell_date(ws.cell(row, 1).value)
    if not dt:
        return None
    rec: dict[str, Any] = {"date": dt.isoformat(), "day": dt.strftime("%a")}
    for col, (_, key) in enumerate(COLUMNS, start=1):
        if key in ("date", "day"):
            continue
        val = ws.cell(row, col).value
        if key == "notes":
            rec[key] = str(val) if val else ""
        else:
            rec[key] = _coerce_float(val)
    return rec


def _is_summary_row(ws, row: int) -> bool:
    val = ws.cell(row, 1).value
    return isinstance(val, str) and "MONTH TOTAL" in val.upper()


def _find_summary_row(ws) -> int | None:
    for row in range(DATA_START_ROW, ws.max_row + 50):
        if _is_summary_row(ws, row):
            return row
    return None


def _last_dated_row(ws) -> int:
    last = DATA_START_ROW - 1
    summary = _find_summary_row(ws) or ws.max_row + 1
    for row in range(DATA_START_ROW, summary):
        if _parse_cell_date(ws.cell(row, 1).value):
            last = row
    return last


def _find_row_for_date(ws, target: date) -> int | None:
    summary = _find_summary_row(ws) or ws.max_row + 1
    for row in range(DATA_START_ROW, summary):
        if _parse_cell_date(ws.cell(row, 1).value) == target:
            return row
    return None


def _find_insert_row(ws) -> int:
    existing = _find_summary_row(ws)
    if existing:
        for row in range(DATA_START_ROW, existing):
            if not _parse_cell_date(ws.cell(row, 1).value):
                return row
        return existing - 1
    return _last_dated_row(ws) + 1


def _update_month_formulas(ws) -> None:
    summary_row = _find_summary_row(ws)
    if not summary_row:
        return
    data_end = max(_last_dated_row(ws), DATA_START_ROW)
    numeric_cols = {
        "cash_sale": 3,
        "cash_kept": 4,
        "cash_expense": 5,
        "card_utap": 6,
        "card_afs": 7,
        "card_network": 8,
        "card_total": 9,
        "total_sales": 10,
        "rifayi": 13,
        "waste_oil": 14,
    }
    for col in numeric_cols.values():
        letter = get_column_letter(col)
        cell = ws.cell(summary_row, col)
        cell.value = f"=SUM({letter}{DATA_START_ROW}:{letter}{data_end})"
        cell.number_format = MONEY_FMT
    avg_row = summary_row + 1
    if ws.cell(avg_row, 1).value and "average" in str(ws.cell(avg_row, 1).value).lower():
        letter = get_column_letter(10)
        ws.cell(avg_row, 10).value = (
            f"=AVERAGE({letter}{DATA_START_ROW}:{letter}{data_end})"
        )
        ws.cell(avg_row, 10).number_format = MONEY_FMT


def _ensure_month_sheet(wb: Workbook, dt: date) -> Any:
    name = month_sheet_name(datetime.combine(dt, datetime.min.time()))
    if name in wb.sheetnames:
        return wb[name]
    ws = wb.create_sheet(title=name)
    ws.merge_cells("A1:R1")
    ws["A1"] = "COFFEE ZONE CAFE — Daily Sales Report"
    ws["A1"].font = Font(bold=True, size=16, color="1F4E79")
    ws.merge_cells("A2:R2")
    ws["A2"] = name
    for col, (label, _) in enumerate(COLUMNS, start=1):
        c = ws.cell(HEADER_ROW, col, value=label)
        c.fill = HEADER_FILL
        c.font = HEADER_FONT
        c.alignment = Alignment(horizontal="center", wrap_text=True)
        c.border = BORDER
    summary_row = DATA_START_ROW + 10
    ws.cell(summary_row, 1, value="MONTH TOTAL / AVERAGE")
    ws.cell(summary_row + 1, 1, value="Daily Average (Sales)")
    return ws


NUMERIC_KEYS = [k for k in FIELD_KEYS if k not in ("date", "day", "notes")]


def normalize_record(data: dict) -> dict:
    """Apply business rules and auto-calculations."""
    rec = {k: data.get(k) for k in FIELD_KEYS}
    dt = data.get("date")
    if isinstance(dt, str):
        rec["date"] = datetime.strptime(dt[:10], "%Y-%m-%d").date()
    elif isinstance(dt, datetime):
        rec["date"] = dt.date()
    elif isinstance(dt, date):
        rec["date"] = dt
    else:
        rec["date"] = date.today()

    for k in NUMERIC_KEYS:
        if rec.get(k) is not None:
            rec[k] = float(rec[k])

    ck = rec.get("cash_kept") or 0
    ce = rec.get("cash_expense") or 0
    if rec.get("cash_sale") is None and (ck or ce):
        rec["cash_sale"] = ck + ce

    utap = rec.get("card_utap") or 0
    afs = rec.get("card_afs") or 0
    net = rec.get("card_network") or 0
    if rec.get("card_total") is None and (utap or afs or net):
        rec["card_total"] = utap + afs + net

    cs = rec.get("cash_sale") or 0
    ct = rec.get("card_total") or 0
    if rec.get("total_sales") is None and (cs or ct):
        rec["total_sales"] = cs + ct

    if rec.get("remaining_cash") is None and rec.get("total_cash_bal") is not None:
        rec["remaining_cash"] = rec["total_cash_bal"]

    rec["day"] = rec["date"].strftime("%a")
    return rec


def _write_row(ws, row: int, rec: dict) -> None:
    for col, (_, key) in enumerate(COLUMNS, start=1):
        cell = ws.cell(row, col)
        val = rec.get(key)
        if key == "date":
            cell.value = rec["date"]
            cell.number_format = DATE_FMT
            cell.alignment = Alignment(horizontal="center")
        elif key == "day":
            cell.value = f'=IF(A{row}="","",TEXT(A{row},"ddd"))'
            cell.alignment = Alignment(horizontal="center")
        elif key == "notes":
            cell.value = val or ""
        elif val is not None:
            cell.value = float(val)
            cell.number_format = MONEY_FMT
            cell.alignment = Alignment(horizontal="right")
        else:
            cell.value = None
        cell.border = BORDER


def backup_folder() -> Path:
    from config import BACKUP_DIR

    folder = Path(BACKUP_DIR)
    folder.mkdir(parents=True, exist_ok=True)
    return folder


def backup_workbook(path: Path) -> Path:
    """Copy workbook to backups folder (timestamped filename)."""
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    dest = backup_folder() / f"{path.stem}_{stamp}{path.suffix}"
    shutil.copy2(path, dest)
    return dest


def load_all_records(path: Path | None = None) -> list[dict]:
    path = path or excel_path()
    if not path.exists():
        return []
    wb = load_workbook(path, data_only=True)
    records: list[dict] = []
    for name in wb.sheetnames:
        if name in SKIP_SHEETS:
            continue
        ws = wb[name]
        if ws.cell(HEADER_ROW, 1).value != "Date":
            continue
        summary = _find_summary_row(ws) or ws.max_row + 1
        for row in range(DATA_START_ROW, summary):
            rec = _row_to_record(ws, row)
            if rec:
                records.append(rec)
    wb.close()
    records.sort(key=lambda r: r["date"])
    return records


def get_record(target: date, path: Path | None = None) -> dict | None:
    for rec in load_all_records(path):
        if rec["date"] == target.isoformat():
            return rec
    return None


def get_latest_record(path: Path | None = None) -> dict | None:
    records = load_all_records(path)
    return records[-1] if records else None


def upsert_record(data: dict, path: Path | None = None) -> dict:
    path = path or excel_path()
    if not path.exists():
        raise FileNotFoundError(f"Excel file not found: {path}")

    rec = normalize_record(data)
    backup_workbook(path)

    wb = load_workbook(path)
    ws = _ensure_month_sheet(wb, rec["date"])
    row = _find_row_for_date(ws, rec["date"]) or _find_insert_row(ws)
    _write_row(ws, row, rec)
    _update_month_formulas(ws)
    wb.save(path)
    wb.close()

    out = {k: (rec[k].isoformat() if k == "date" else rec.get(k)) for k in FIELD_KEYS}
    out["date"] = rec["date"].isoformat()
    out["_excel_row"] = row
    out["_sheet"] = ws.title
    return out


def record_to_export_row(rec: dict) -> dict:
    row = dict(rec)
    for k in NUMERIC_KEYS:
        if row.get(k) is not None:
            row[k] = round(float(row[k]), 2)
    return row


def upsert_records_batch(data_list: list[dict], path: Path | None = None) -> list[dict]:
    """Save multiple days in one Excel open/save (one backup)."""
    if not data_list:
        return []
    path = path or excel_path()
    if not path.exists():
        raise FileNotFoundError(f"Excel file not found: {path}")

    backup_workbook(path)
    wb = load_workbook(path)
    saved: list[dict] = []

    for data in data_list:
        rec = normalize_record(data)
        ws = _ensure_month_sheet(wb, rec["date"])
        row = _find_row_for_date(ws, rec["date"]) or _find_insert_row(ws)
        _write_row(ws, row, rec)
        _update_month_formulas(ws)
        out = {k: (rec[k].isoformat() if k == "date" else rec.get(k)) for k in FIELD_KEYS}
        out["date"] = rec["date"].isoformat()
        out["_excel_row"] = row
        out["_sheet"] = ws.title
        saved.append(out)

    wb.save(path)
    wb.close()
    return saved
