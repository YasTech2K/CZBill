"""
Parse Coffee Zone daily sales from WhatsApp export and build Excel report.
"""
from __future__ import annotations

import re
from collections import defaultdict
from datetime import datetime
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

RAW_FILE = Path(__file__).parent / "CZ_Daily_bill_data_from Day1_Rasheed chat.txt"
OUTPUT_FILE = Path(__file__).parent / "Coffee_Zone_Daily_Sales_Report.xlsx"

COLUMNS = [
    ("Date", "date"),
    ("Day", "day"),
    ("Cash Sale (AED)", "cash_sale"),
    ("Cash Kept (AED)", "cash_kept"),
    ("Cash Expense (AED)", "cash_expense"),
    ("Card U-Tap (AED)", "card_utap"),
    ("Card AFS (AED)", "card_afs"),
    ("Card Network (AED)", "card_network"),
    ("Total Card (AED)", "card_total"),
    ("Total Sales (AED)", "total_sales"),
    ("Opening Cash (AED)", "opening_cash"),
    ("Total Cash Bal. (AED)", "total_cash_bal"),
    ("Paid to Rifayi (AED)", "rifayi"),
    ("Waste Oil (AED)", "waste_oil"),
    ("Float (AED)", "float_cash"),
    ("Petty Cash (AED)", "petty_cash"),
    ("Remaining Cash (AED)", "remaining_cash"),
    ("Old Card Bal. (AED)", "old_card_bal"),
    ("Notes", "notes"),
]


def parse_amount(text: str | None) -> float | None:
    if not text:
        return None
    s = str(text).upper().replace("AED", "").replace(",", "").strip()
    s = re.sub(r"[^\d.\-+]", "", s)
    if not s or s in (".", "-", "+"):
        return None
    try:
        return float(s)
    except ValueError:
        return None


def first_amount(line: str) -> float | None:
    m = re.search(r"([\d,]+(?:\.\d+)?)", line.replace(",", ""))
    return parse_amount(m.group(1)) if m else None


def parse_cash_sale_line(line: str) -> tuple[float | None, float | None, float | None]:
    """Returns (cash_kept, cash_expense, cash_sale_total)."""
    upper = line.upper()
    if "+" in line and "=" in line:
        parts = re.split(r"=", line, maxsplit=1)
        total = parse_amount(parts[-1])
        left = parts[0]
        nums = re.findall(r"([\d,]+(?:\.\d+)?)", left)
        nums = [parse_amount(n) for n in nums]
        nums = [n for n in nums if n is not None]
        if len(nums) >= 2:
            return nums[0], nums[1], total
        if len(nums) == 1:
            return nums[0], None, total
    val = first_amount(line)
    return None, None, val


def parse_date_from_block(block: str) -> datetime | None:
    patterns = [
        r"Date:\s*(\d{1,2})[/:](\d{1,2})[/:](\d{4})",
        r"Date:\s*(\d{1,2})\s*/\s*(\d{1,2})\s*/\s*(\d{4})",
        r"^\s{1,3}(\d{1,2}/\d{1,2}/\d{4})\s*$",
    ]
    for pat in patterns[:2]:
        m = re.search(pat, block, re.IGNORECASE | re.MULTILINE)
        if m:
            d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if 1 <= mo <= 12 and 1 <= d <= 31:
                try:
                    return datetime(y, mo, d)
                except ValueError:
                    pass
    for line in block.splitlines():
        stripped = line.strip()
        m = re.match(r"^(\d{1,2}/\d{1,2}/\d{4})(?:\s+\w+)?$", stripped)
        if m:
            try:
                return datetime.strptime(m.group(1), "%d/%m/%Y")
            except ValueError:
                pass
    return None


def split_blocks(text: str) -> list[str]:
    parts = re.split(
        r"(?=(?:\[\d{1,2}/\d{1,2}/\d{4}.*?\]|\[\d{1,2}:\d{2}\s*[AP]M.*?\])\s*[^:\n]*:\s*BISMILLAH|^BISMILLAH)",
        text,
        flags=re.IGNORECASE | re.MULTILINE,
    )
    blocks = []
    for p in parts:
        p = p.strip()
        if not p or len(p) < 30:
            continue
        if "cash sale" in p.lower() or "cash:" in p.lower() or "total sale" in p.lower():
            blocks.append(p)
    return blocks


def parse_block(block: str) -> dict | None:
    dt = parse_date_from_block(block)
    if not dt:
        return None

    rec: dict = {
        "date": dt,
        "day": dt.strftime("%a"),
        "cash_sale": None,
        "cash_kept": None,
        "cash_expense": None,
        "card_utap": None,
        "card_afs": None,
        "card_network": None,
        "card_total": None,
        "total_sales": None,
        "opening_cash": None,
        "total_cash_bal": None,
        "rifayi": None,
        "waste_oil": None,
        "float_cash": None,
        "petty_cash": None,
        "remaining_cash": None,
        "old_card_bal": None,
        "notes": "",
    }

    lines = [ln.strip() for ln in block.splitlines() if ln.strip()]
    lower_block = block.lower()

    # Alternate compact format (e.g. 13/04/2026)
    if "today sales details" in lower_block and "cash:" in lower_block:
        for ln in lines:
            ll = ln.lower()
            if ll.startswith("cash:") and "bill" not in ll:
                rec["cash_sale"] = first_amount(ln)
            elif "bill paid cash" in ll:
                rec["cash_expense"] = (rec["cash_expense"] or 0) + (first_amount(ln) or 0)
            elif ll.startswith("coins"):
                coins = first_amount(ln) or 0
                rec["cash_kept"] = coins
            elif "u-tap" in ll or "u tap" in ll:
                rec["card_utap"] = first_amount(ln)
            elif "afs" in ll:
                rec["card_afs"] = first_amount(ln)
            elif "rabbani" in ll:
                rec["card_network"] = first_amount(ln)
            elif "total sale" in ll:
                rec["total_sales"] = first_amount(ln)
            elif "float" in ll:
                rec["float_cash"] = first_amount(ln)
        cards = [x for x in (rec["card_utap"], rec["card_afs"], rec["card_network"]) if x]
        if cards:
            rec["card_total"] = sum(cards)
        return rec

    for ln in lines:
        ll = ln.lower().replace("*", "").strip()

        if "today cash sale" in ll:
            k, e, t = parse_cash_sale_line(ln)
            rec["cash_kept"] = k if k is not None else rec["cash_kept"]
            rec["cash_expense"] = e if e is not None else rec["cash_expense"]
            rec["cash_sale"] = t if t is not None else rec["cash_sale"]
        elif ll.startswith("today cash sale:"):
            k, e, t = parse_cash_sale_line(ln)
            rec["cash_kept"] = k
            rec["cash_expense"] = e
            rec["cash_sale"] = t
        elif re.match(r"today cash sale\s*[-:]", ll):
            rec["cash_sale"] = first_amount(ln)
        elif "card sale (u-tap)" in ll or "card   u tap sale" in ll or "u tap sale" in ll:
            rec["card_utap"] = first_amount(ln)
        elif "card sale (afs)" in ll or "card afs sale" in ll:
            rec["card_afs"] = first_amount(ln)
        elif "rabbani" in ll and "card" in ll:
            rec["card_network"] = first_amount(ln)
        elif re.match(r"today card sale\s*[-:]", ll) and "u tap" not in ll and "afs" not in ll:
            if rec["card_total"] is None:
                rec["card_total"] = first_amount(ln)
        elif "today toatal sale" in ll or "today total sale" in ll:
            rec["total_sales"] = first_amount(ln)
        elif "today exp" in ll or "expense (from cash)" in ll:
            if rec["cash_expense"] is None:
                rec["cash_expense"] = first_amount(ln)
        elif "today cash balance" in ll:
            if rec["cash_kept"] is None:
                rec["cash_kept"] = first_amount(ln)
        elif "opening cash balance" in ll or "old cash balance" in ll:
            rec["opening_cash"] = first_amount(ln)
        elif re.match(r"total cash balance", ll) and "toatal" not in ll and "remaining" not in ll:
            rec["total_cash_bal"] = first_amount(ln)
        elif "toatal cash balance" in ll:
            rec["total_cash_bal"] = first_amount(ln)
        elif "remaining cash balance" in ll:
            rec["remaining_cash"] = first_amount(ln)
        elif "rifayi" in ll or "rifayi" in ll:
            v = first_amount(ln)
            if v and v > 0:
                rec["rifayi"] = v
        elif "waste oil" in ll or "vest oil" in ll:
            v = first_amount(ln)
            if v and v > 0:
                rec["waste_oil"] = v
        elif "float cash" in ll or ll.startswith("float cash"):
            rec["float_cash"] = first_amount(ln)
        elif "petty cash" in ll:
            rec["petty_cash"] = first_amount(ln)
        elif "old card balance" in ll:
            rec["old_card_bal"] = first_amount(ln)
        elif "given to rifayi" in ll:
            v = first_amount(ln)
            if v:
                rec["rifayi"] = v
        elif "cash balance-" in ll.replace(" ", "") and "given" in lower_block:
            pass

    # Legacy: derive card total
    if rec["card_total"] is None:
        parts = [rec["card_utap"], rec["card_afs"], rec["card_network"]]
        nums = [p for p in parts if p is not None]
        if nums:
            rec["card_total"] = sum(nums)

    # Legacy total sales
    if rec["total_sales"] is None and rec["cash_sale"] and rec["card_total"]:
        exp = rec["cash_expense"] or 0
        rec["total_sales"] = rec["cash_sale"] + rec["card_total"]

    if rec["cash_sale"] is None and rec["cash_kept"] and rec["cash_expense"]:
        rec["cash_sale"] = rec["cash_kept"] + rec["cash_expense"]

    if rec["remaining_cash"] is None:
        rec["remaining_cash"] = rec["total_cash_bal"]

    return rec


def completeness(rec: dict) -> int:
    keys = [
        "cash_sale",
        "total_sales",
        "card_utap",
        "card_afs",
        "opening_cash",
        "remaining_cash",
    ]
    return sum(1 for k in keys if rec.get(k) is not None)


def load_records(path: Path) -> list[dict]:
    text = path.read_text(encoding="utf-8", errors="replace")
    by_date: dict[str, dict] = {}
    for block in split_blocks(text):
        rec = parse_block(block)
        if not rec:
            continue
        key = rec["date"].strftime("%Y-%m-%d")
        if key not in by_date or completeness(rec) > completeness(by_date[key]):
            by_date[key] = rec
    return sorted(by_date.values(), key=lambda r: r["date"])


# --- Excel styling ---
HEADER_FILL = PatternFill("solid", fgColor="1F4E79")
HEADER_FONT = Font(bold=True, color="FFFFFF", size=11)
TITLE_FONT = Font(bold=True, size=16, color="1F4E79")
SUBTITLE_FONT = Font(size=11, color="404040", italic=True)
SUMMARY_FILL = PatternFill("solid", fgColor="D6E4F0")
ALT_FILL = PatternFill("solid", fgColor="F2F7FB")
THIN = Side(style="thin", color="B4C6E7")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
MONEY_FMT = '#,##0.00'
DATE_FMT = "DD/MM/YYYY"


def style_header_row(ws, row: int, col_count: int) -> None:
    for c in range(1, col_count + 1):
        cell = ws.cell(row=row, column=c)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BORDER


def set_col_widths(ws, widths: list[float]) -> None:
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w


BLANK_ENTRY_ROWS = 8


def add_month_sheet(
    wb: Workbook, month_key: str, records: list[dict], *, template_only: bool = False
) -> None:
    title = datetime.strptime(month_key + "-01", "%Y-%m-%d").strftime("%B %Y")
    ws = wb.create_sheet(title=title[:31])

    ws.merge_cells("A1:R1")
    ws["A1"] = "COFFEE ZONE CAFE — Daily Sales Report"
    ws["A1"].font = TITLE_FONT
    ws.merge_cells("A2:R2")
    ws["A2"] = title
    ws["A2"].font = SUBTITLE_FONT

    header_row = 4
    for col, (label, _) in enumerate(COLUMNS, start=1):
        ws.cell(row=header_row, column=col, value=label)
    style_header_row(ws, header_row, len(COLUMNS))

    data_start = header_row + 1
    for i, rec in enumerate(records):
        row = data_start + i
        for col, (_, key) in enumerate(COLUMNS, start=1):
            val = rec.get(key)
            cell = ws.cell(row=row, column=col, value=val)
            cell.border = BORDER
            if key == "date":
                cell.number_format = DATE_FMT
                cell.alignment = Alignment(horizontal="center")
            elif key == "day":
                cell.alignment = Alignment(horizontal="center")
            elif key == "notes":
                cell.alignment = Alignment(wrap_text=True)
            elif key != "notes" and isinstance(val, (int, float)):
                cell.number_format = MONEY_FMT
                cell.alignment = Alignment(horizontal="right")
            if i % 2 == 1:
                cell.fill = ALT_FILL

    entry_start = data_start + len(records)
    for j in range(BLANK_ENTRY_ROWS):
        row = entry_start + j
        for col, (_, key) in enumerate(COLUMNS, start=1):
            cell = ws.cell(row=row, column=col)
            cell.border = BORDER
            if key == "date":
                cell.number_format = DATE_FMT
                cell.alignment = Alignment(horizontal="center")
            elif key == "day":
                cell.alignment = Alignment(horizontal="center")
            elif key not in ("notes", "day") and col > 2:
                cell.number_format = MONEY_FMT
                cell.alignment = Alignment(horizontal="right")
        day_cell = ws.cell(row=row, column=2)
        day_cell.value = f'=IF(A{row}="","",TEXT(A{row},"ddd"))'

    last_data = entry_start + BLANK_ENTRY_ROWS - 1
    if len(records) == 0 and template_only:
        last_data = max(last_data, data_start)
    sum_end = data_start + len(records) - 1 if len(records) else data_start
    summary_row = last_data + 2
    ws.cell(row=summary_row, column=1, value="MONTH TOTAL / AVERAGE").font = Font(bold=True)
    ws.cell(row=summary_row, column=1).fill = SUMMARY_FILL

    numeric_cols = {
        "cash_sale": 3,
        "cash_kept": 4,
        "cash_expense": 5,
        "card_utap": 6,
        "card_afs": 7,
        "card_network": 8,
        "card_total": 9,
        "total_sales": 10,
        "rifayi": 13,
        "waste_oil": 14,
    }
    for key, col in numeric_cols.items():
        letter = get_column_letter(col)
        cell = ws.cell(row=summary_row, column=col)
        cell.value = f"=SUM({letter}{data_start}:{letter}{sum_end})"
        cell.font = Font(bold=True)
        cell.fill = SUMMARY_FILL
        cell.number_format = MONEY_FMT
        cell.border = BORDER

    avg_row = summary_row + 1
    ws.cell(row=avg_row, column=1, value="Daily Average (Sales)").font = Font(italic=True)
    if len(records) > 0:
        letter = get_column_letter(10)
        c = ws.cell(row=avg_row, column=10)
        c.value = f"=AVERAGE({letter}{data_start}:{letter}{sum_end})"
        c.number_format = MONEY_FMT
        c.font = Font(italic=True)

    ws.freeze_panes = ws.cell(row=data_start, column=1)
    ws.auto_filter.ref = (
        f"A{header_row}:{get_column_letter(len(COLUMNS))}{max(last_data, header_row)}"
    )

    data_end = data_start + max(len(records), 1) - 1
    if len(records) > 0:
        tab_ref = f"A{header_row}:{get_column_letter(len(COLUMNS))}{data_end}"
        tab = Table(displayName=f"T_{month_key.replace('-', '_')}", ref=tab_ref)
        tab.tableStyleInfo = TableStyleInfo(
            name="TableStyleMedium2",
            showFirstColumn=False,
            showLastColumn=False,
            showRowStripes=True,
            showColumnStripes=False,
        )
        ws.add_table(tab)

    set_col_widths(
        ws,
        [12, 6, 14, 14, 14, 12, 12, 12, 12, 14, 14, 14, 12, 10, 8, 10, 14, 12, 18],
    )
    ws.row_dimensions[1].height = 28
    ws.row_dimensions[header_row].height = 36


def add_dashboard(wb: Workbook, by_month: dict[str, list[dict]]) -> None:
    ws = wb.create_sheet(title="Dashboard", index=0)
    ws.merge_cells("A1:F1")
    ws["A1"] = "COFFEE ZONE CAFE — Sales Dashboard"
    ws["A1"].font = TITLE_FONT
    ws.merge_cells("A2:F2")
    ws["A2"] = "Summary by month (all amounts in AED)"
    ws["A2"].font = SUBTITLE_FONT

    headers = ["Month", "Days Recorded", "Total Sales", "Total Cash Sales", "Total Card", "Avg Daily Sales"]
    hr = 4
    for c, h in enumerate(headers, 1):
        ws.cell(row=hr, column=c, value=h)
    style_header_row(ws, hr, len(headers))

    row = hr + 1
    for month_key in sorted(by_month.keys()):
        recs = by_month[month_key]
        title = datetime.strptime(month_key + "-01", "%Y-%m-%d").strftime("%b %Y")
        sheet_name = datetime.strptime(month_key + "-01", "%Y-%m-%d").strftime("%B %Y")[:31]
        days = len(recs)
        total_sales = sum(r.get("total_sales") or 0 for r in recs)
        cash = sum(r.get("cash_sale") or 0 for r in recs)
        card = sum(r.get("card_total") or 0 for r in recs)
        avg = total_sales / days if days else 0
        ws.cell(row=row, column=1, value=title)
        ws.cell(row=row, column=2, value=days)
        for col, val in enumerate([total_sales, cash, card, avg], start=3):
            cell = ws.cell(row=row, column=col, value=val)
            cell.number_format = MONEY_FMT
        row += 1

    ws.freeze_panes = "A5"
    set_col_widths(ws, [14, 14, 16, 16, 14, 16])


def add_instructions(wb: Workbook) -> None:
    ws = wb.create_sheet(title="How to Use")
    lines = [
        "HOW TO USE THIS WORKBOOK",
        "",
        "1. Dashboard — overview of each month.",
        "2. Monthly sheets — one row per business day; add new rows at the bottom (copy formulas from summary row if needed).",
        "3. Date format: use DD/MM/YYYY in the Date column.",
        "4. Cash Sale = cash kept + expenses paid from cash (when you use split format in WhatsApp).",
        "5. After entering a new day, month totals at the bottom update automatically.",
        "6. Keep a backup copy before major edits.",
        "",
        "Source: imported from WhatsApp daily reports (Rasheed).",
        f"Generated: {datetime.now().strftime('%d/%m/%Y %H:%M')}",
    ]
    for i, line in enumerate(lines, 1):
        cell = ws.cell(row=i, column=1, value=line)
        if i == 1:
            cell.font = Font(bold=True, size=14, color="1F4E79")
    ws.column_dimensions["A"].width = 70


def build_workbook(records: list[dict]) -> Workbook:
    wb = Workbook()
    wb.remove(wb.active)

    by_month: dict[str, list[dict]] = defaultdict(list)
    for rec in records:
        by_month[rec["date"].strftime("%Y-%m")].append(rec)

    add_dashboard(wb, by_month)
    for month_key in sorted(by_month.keys()):
        add_month_sheet(wb, month_key, by_month[month_key])

    # Empty sheet for current / next month so you can type new days without rebuilding
    today = datetime.now()
    future_key = today.strftime("%Y-%m")
    if future_key not in by_month:
        add_month_sheet(wb, future_key, [], template_only=True)

    add_instructions(wb)
    return wb


def main() -> None:
    records = load_records(RAW_FILE)
    print(f"Parsed {len(records)} unique days from {RAW_FILE.name}")
    if records:
        print(f"  Range: {records[0]['date'].date()} to {records[-1]['date'].date()}")
        months = sorted({r["date"].strftime("%Y-%m") for r in records})
        print(f"  Months: {', '.join(months)}")
    wb = build_workbook(records)
    wb.save(OUTPUT_FILE)
    print(f"Saved: {OUTPUT_FILE}")


if __name__ == "__main__":
    main()
