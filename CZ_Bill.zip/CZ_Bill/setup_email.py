#!/usr/bin/env python3
"""Interactive script to configure email sharing for Coffee Zone Portal."""
from __future__ import annotations

import getpass
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "portal"))

from email_service import PROVIDERS, apply_provider_preset  # noqa: E402
from env_manager import write_env_values  # noqa: E402


def main() -> None:
    print("\n=== Coffee Zone — Email setup ===\n")
    print("Choose provider:")
    keys = list(PROVIDERS.keys())
    for i, k in enumerate(keys, 1):
        print(f"  {i}. {PROVIDERS[k]['label']} ({k})")
    choice = input("\nNumber [1]: ").strip() or "1"
    try:
        provider = keys[int(choice) - 1]
    except (ValueError, IndexError):
        provider = "gmail"

    updates = apply_provider_preset(provider)
    preset = PROVIDERS[provider]
    print(f"\n{preset.get('help', '')}\n")

    if provider == "custom":
        updates["SMTP_HOST"] = input("SMTP host: ").strip()
        updates["SMTP_PORT"] = input("SMTP port [587]: ").strip() or "587"

    user = input("Your email address: ").strip()
    if not user:
        print("Email is required.")
        sys.exit(1)
    updates["SMTP_USER"] = user
    updates["SMTP_FROM"] = input(f"Send from [{user}]: ").strip() or user
    updates["SMTP_PASSWORD"] = getpass.getpass("App password (hidden): ").strip()
    default_to = input("Default report recipient (optional): ").strip()
    if default_to:
        updates["DEFAULT_REPORT_EMAIL"] = default_to

    write_env_values(updates)
    env_path = ROOT / ".env"
    print(f"\nSaved to {env_path}")
    print("Restart the portal, then open: http://127.0.0.1:5050/settings/email")
    print("Click 'Send test email' to verify.\n")


if __name__ == "__main__":
    main()
